import numpy as np      ## Library with linear algebra functions/matrix analysis 
import matplotlib.pyplot    ## Library with graph and other plotting functions
import pandas as pd     ## Library with data set visualization and analysis functions
import seaborn         ## Library helping your visualizations look better